							</div>
							</div>
							</div> <!-- end of row sidebar -->



							<footer class="bg-secondary bgme-f text-center p-3">
							    <p class="mb-0">Academy Batch 2</p>
							</footer>
							</div>

							</body>

							</html>