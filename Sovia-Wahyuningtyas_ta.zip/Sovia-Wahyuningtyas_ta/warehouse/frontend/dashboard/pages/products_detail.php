<?php
	// Include header and sidebar of templates
	include_once('../templates/header.php');

    // get product by id
    $product_query= mysqli_query($link, "SELECT * FROM products WHERE id=".$_GET['id']);
    $product =  mysqli_fetch_assoc($product_query);
?>




<div class="card">
    <div class="card-header bg-dark text-white">
        <h3>
        <a href="<?= BASE_URL.'/frontend/dashboard/pages/products.php' ?>" class="text-decoration-none text-white">
                        <i class="bi bi-arrow-left-circle"></i>
                </a>
            Detail
        </h3>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-3">
                <h6>Kode Produk</h6>
            </div>
            <div class="col-9"><?=$product['code']?></div>
            <div class="col-3">
                <h6>Nama Produk</h6>
            </div>
            <div class="col-9"><?=$product['name']?></div>
            <div class="col-3">
                <h6>Stok</h6>
            </div>
            <div class="col-9"><?=$product['stock']?></div>
            <div class="col-3">
                <h6>Price</h6>
            </div>
            <div class="col-9"><?=rupiah($product['price'])?></div>
            <div class="col-3">
                <h6>Kategori</h6>
            </div>
            <div class="col-9"><?=$product['category']?></div>

        </div>
    </div>
</div>



<?php
	// Include footer of templates
	include_once('../templates/footer.php');
?>