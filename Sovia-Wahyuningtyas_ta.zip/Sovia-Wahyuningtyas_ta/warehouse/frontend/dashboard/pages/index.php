<?php
	// Include header and sidebar of templates
	include_once('../templates/header.php');

	//parr($_SESSION);
?>


<div class="card">
    <div class="card-header bg-dark text-white">
        <h3>Dashboard</h3>
    </div>
    <div class="card-body">
        <p>Selamat datang di Dashboard Warehouse! Sebuah Aplikasi yang kami buat untuk memudahkan Anda dalam mengelola
            data barang di toko komputer Anda. Fitur unggulan kami termasuk fitur manajemen data produk yang
            komprehensif, yang mencakup informasi penting berikut:</p>

        <p>1. Kode Produk: Identifikasi produk Anda dengan mudah menggunakan kode unik yang memudahkan dalam pelacakan
            dan pengelolaan.</p>

        <p>2. Nama Produk: Lengkapi daftar produk dengan nama yang jelas dan deskriptif untuk membantu pelanggan
            mengidentifikasi produk yang mereka cari.</p>

        <p>3. Stok: Pantau stok barang Anda secara real-time agar Anda selalu tahu ketersediaan produk dan dapat
            menghindari kehabisan stok.</p>

        <p>4. Price: Tetapkan harga yang kompetitif dan sesuai untuk setiap produk, dan pastikan pelanggan mendapatkan
            nilai terbaik dari pembelian mereka.</p>

        <p>5. Kategori: Kelompokkan produk berdasarkan kategori yang relevan untuk membantu pelanggan menemukan produk
            dengan lebih mudah.</p>

        <p>Dengan fitur-fitur ini, Anda dapat mengelola inventaris dengan lebih efisien, memantau penjualan dengan
            akurat, dan mengoptimalkan strategi pemasaran dan stok produk. Warehouse hadir untuk membantu toko komputer
            Anda tumbuh dan sukses dalam pasar yang semakin kompetitif. Selamat menjelajahi dan nikmati kemudahan
            pengelolaan data barang dengan aplikasi kami yang inovatif!
        </p>
    </div>
</div>

<?php
	// Include footer of templates
	include_once('../templates/footer.php');
?>