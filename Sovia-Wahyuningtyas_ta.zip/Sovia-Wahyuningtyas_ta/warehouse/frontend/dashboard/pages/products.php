<?php
	// Include header and sidebar of templates
	include_once('../templates/header.php');
?>


<div class="card">
    <div class="card-header bg-dark text-white">

        <h3>Products
            <a href="<?= BASE_URL.'frontend/dashboard/pages/products_create.php' ?>"
                class="btn btn-sm btn-primary float-end">Create</a>
        </h3>

    </div>
    <div class="card-body">
        <table class="table table-bordered">

            <?php 
if(isset($_SESSION['success'])) {
    echo '<div class="alert alert-success" role="alert">
    '.$_SESSION['success'].'
    </div>';
    unset($_SESSION['success']);
}elseif(isset($_SESSION['error'])){
    echo '<div class="alert alert-danger" role="alert">
    '.$_SESSION['error'].'
    </div>';
    unset($_SESSION['error']);
}

?>

            <thead>
                <tr>
                    <th scope="col" width="15%">Kode Produk</th>
                    <th scope="col">Nama Produk</th>
                    <th scope="col">Stok</th>
                    <th scope="col">Price</th>
                    <th scope="col">Kategori</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>

                <?php 
                        $products= mysqli_query($link, "SELECT * FROM products"); 
                        while($product = $products->fetch_assoc()) {    
                            echo "
                            <tr>
                                <td>".$product['code']."</td>
                                <td>".$product['name']."</td>
                                <td>".$product['stock']."</td>
                                <td>".rupiah($product['price'])."</td>
                                <td>".$product['category']."</td>
                                <td><a href='".BASE_URL."frontend/dashboard/pages/products_update.php?id=".$product['id']."'
                                class='btn btn-sm btn-warning'>Ubah</a>
                                <a href='".BASE_URL."backend/product_delete.php?id=".$product['id']."'
                                class='btn btn-sm btn-danger hapus'>Hapus</a>
                                <a href='".BASE_URL."frontend/dashboard/pages/products_detail.php?id=".$product['id']."'
                                class='btn btn-sm btn-info'>Detail</a>
                                </td>
                            </tr>";
                        }
                        if(mysqli_num_rows($products) == 0){
                            echo "<tr><td class='text-center' colspan='5'>Tidak Ada Product</td></tr>";
                        }
                        ?>
            </tbody>
        </table>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Apakah anda yakin untuk menghapus produk?</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <a class="btn btn-danger">Hapus</a>
            </div>
        </div>
    </div>
</div>

<script>
$(".hapus").on('click', (event) => {
    event.preventDefault();
    $("#exampleModal").modal("show")
    $("#exampleModal a").attr('href', $(event.target).attr('href'))
})
</script>

<?php
	// Include footer of templates
	include_once('../templates/footer.php');
?>