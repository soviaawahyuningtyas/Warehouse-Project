<?php
	// Include header and sidebar of templates
	include_once('../templates/header.php');

    // get product by id
    $product_query= mysqli_query($link, "SELECT * FROM products WHERE id=".$_GET['id']);
    $product =  mysqli_fetch_assoc($product_query);
?>




<div class="card">
    <div class="card-header bg-dark text-white">
        <h3>
            <h3>
                <a href="<?= BASE_URL.'/frontend/dashboard/pages/products.php' ?>" class="text-decoration-none text-white">
                        <i class="bi bi-arrow-left-circle"></i>
                </a>
                Ubah
            </h3>
        </h3>
    </div>
    <div class="card-body">
        <form action="<?=BASE_URL.'backend/product_update.php?id='.$_GET['id']?>" method="post">
            <div class="form-group">
                <label for="">Kode Produk</label>
                <input type="text" name="code" class="form-control" required value="<?=$product['code']?>">
            </div>
            <div class="form-group">
                <label for="">Nama</label>
                <input type="text" name="name" class="form-control" required value="<?=$product['name']?>">
            </div>
            <div class="form-group">
                <label for="">Stok</label>
                <input type="number" name="stock" class="form-control" required value="<?=$product['stock']?>">
            </div>
            <div class="form-group">
                <label for="">Price</label>
                <input type="number" name="price" class="form-control" required value="<?=$product['price']?>">
            </div>
            <div class="form-group">
                <label for="">Category</label>
                <input type="text" name="category" class="form-control" required value="<?=$product['category']?>">
            </div>
            <button type="submit" class="btn btn-sm btn-primary float-end mt-3">Simpan</button>
        </form>
    </div>
</div>



<?php
	// Include footer of templates
	include_once('../templates/footer.php');
?>