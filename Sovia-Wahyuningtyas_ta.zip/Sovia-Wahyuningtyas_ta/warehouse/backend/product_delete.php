<?php 
include_once('../config/helper.php');

// Catch
$id   = $_GET['id'];

// Run query create
$runQuery = mysqli_query($link, "DELETE FROM products WHERE id=".$id);

// cek error
if(!$runQuery){
    $_SESSION['error'] = mysqli_error($link);
}else{

    // Session message
    $_SESSION['success'] = "Berhasil Menghapus Produk";

}



// Redirect
header('Location: '.BASE_URL.'frontend/dashboard/pages/products.php');

?>