<?php 
include_once('../config/helper.php');

// Catch
$code   = $_POST['code'];
$name   = $_POST['name'];
$price  = $_POST['price'];
$stock  = $_POST['stock'];
$category      = $_POST['category'];
$users_by = $_SESSION['auth']['id'];

// Run query create
$runQuery = mysqli_query($link, "INSERT INTO products (code,name,stock,price,category,users_by) VALUES('$code','$name','$stock','$price','$category','$users_by')");

// cek error
if(!$runQuery){
    $_SESSION['error'] = mysqli_error($link);
}else{

    // Session message
    $_SESSION['success'] = "Berhasil Menambah Produk";
}



// Redirect
header('Location: '.BASE_URL.'frontend/dashboard/pages/products.php');

?>