<?php
//helper
require_once('../config/helper.php');

//Debug
//parr($_REQUEST);


// Check is exist already session
if (empty($_SESSION) === false ){
    // logout action
    session_destroy();
    header('Location: '.BASE_URL.'frontend/login.php');
} else {
    // login action

    // Catch data form
    $username = $_POST['username'];
    $password = $_POST['password'];

    //check username on database
    $runQuery = mysqli_query($link, "SELECT * FROM users WHERE username = '".$username."'");

    if(mysqli_num_rows($runQuery) === 1){

    $dataUser =  mysqli_fetch_assoc($runQuery);

    // process validation
    if (password_verify($password, $dataUser['password'])){

    // remove field password
    unset($dataUser['password']);
    // Go to dashboard
    $_SESSION['auth'] = $dataUser;
    parr($dataUser);

    header('Location: '.BASE_URL.'frontend/dashboard/pages/index.php');
    } else {
    //password is'nt correct
    $_SESSION['auth'] = false;
    header('Location: '.BASE_URL.'frontend/login.php');
    }

    } else {
    //account is'nt yet register
        $_SESSION['auth'] = 'noregist';
    header('Location: '.BASE_URL.'frontend/login.php');

    }
}