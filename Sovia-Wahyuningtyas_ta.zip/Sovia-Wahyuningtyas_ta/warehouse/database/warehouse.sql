-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Jul 2023 pada 12.50
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `warehouse`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `config_app`
--

CREATE TABLE `config_app` (
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `version` char(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `config_app`
--

INSERT INTO `config_app` (`name`, `description`, `version`) VALUES
('Aplikasi Warehouse', 'Yaitu sebuah aplikasi yang mengelola data barang di toko komputer.', '3.0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `code` char(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL,
  `price` int(10) NOT NULL,
  `category` varchar(255) NOT NULL,
  `users_by` int(5) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `products`
--

INSERT INTO `products` (`id`, `code`, `name`, `stock`, `price`, `category`, `users_by`, `created_at`) VALUES
(0, '001', 'Access Point Ruijie', 5, 1650000, 'Peralatan Jaringan', 1, '2023-07-28 10:28:46'),
(5, '002', 'Kabel LAN Cat 5E merk Interluc per meter', 6000, 3000, 'Kabel', 1, '2023-07-28 14:47:33'),
(6, '003', 'Tang Crimping', 35, 34000, 'Peralatan Jaringan', 1, '2023-07-28 14:48:14'),
(7, '004', 'LAN tester', 25, 36000, 'Peralatan Jaringan', 1, '2023-07-28 14:51:32'),
(8, '005', 'Konektor RJ45 isi 100 pcs', 48, 32000, 'Peralatan Jaringan', 1, '2023-07-28 14:53:06'),
(9, '006', 'Keyboard USB Logitechh', 15, 110000, 'Perlengkapan', 1, '2023-07-28 14:54:03'),
(10, '007', 'Mouse USB brand Acer', 22, 20000, 'Perlengkapan', 1, '2023-07-28 14:54:54'),
(11, '008', 'Mouse Wireless Logitech', 10, 117000, 'Perlengkapan', 1, '2023-07-28 14:56:12'),
(12, '009', 'Router TP-Link TL-WR820N', 8, 135000, 'Peralatan Jaringan', 1, '2023-07-28 14:57:07'),
(13, '010', 'Micro SD Sandisk Ultra 16 GB', 14, 48000, 'Perlengkapan', 1, '2023-07-28 14:58:56');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `username` char(8) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `roles` enum('staff','leader') NOT NULL,
  `status` enum('a','s','n') NOT NULL COMMENT 'a = active, s = suspend, n = nonactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fullname`, `roles`, `status`) VALUES
(1, 'joni', '$2y$10$OJ8FxR22.7lJjP/Kw4oOjuU2ZYyCz79D9vC3aGR2TA5FBlMJjldnC', 'Abang Joni', 'leader', 'a'),
(2, 'putri', '$2y$10$bdiKVprxpC0Qy3RHBWDLYuFiJDWlk2MjZsaXtAvbd961voJborZfK', 'Putri Candrawati', 'staff', 'a');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `users_by` (`users_by`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
